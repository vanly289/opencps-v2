/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.fds.vr.business.service.persistence;

import aQute.bnd.annotation.ProviderType;

import com.fds.vr.business.exception.NoSuchVRInspectionStandardException;
import com.fds.vr.business.model.VRInspectionStandard;

import com.liferay.portal.kernel.service.persistence.BasePersistence;

/**
 * The persistence interface for the vr inspection standard service.
 *
 * <p>
 * Caching information and settings can be found in <code>portal.properties</code>
 * </p>
 *
 * @author LamTV
 * @see com.fds.vr.business.service.persistence.impl.VRInspectionStandardPersistenceImpl
 * @see VRInspectionStandardUtil
 * @generated
 */
@ProviderType
public interface VRInspectionStandardPersistence extends BasePersistence<VRInspectionStandard> {
	/*
	 * NOTE FOR DEVELOPERS:
	 *
	 * Never modify or reference this interface directly. Always use {@link VRInspectionStandardUtil} to access the vr inspection standard persistence. Modify <code>service.xml</code> and rerun ServiceBuilder to regenerate this interface.
	 */

	/**
	* Caches the vr inspection standard in the entity cache if it is enabled.
	*
	* @param vrInspectionStandard the vr inspection standard
	*/
	public void cacheResult(VRInspectionStandard vrInspectionStandard);

	/**
	* Caches the vr inspection standards in the entity cache if it is enabled.
	*
	* @param vrInspectionStandards the vr inspection standards
	*/
	public void cacheResult(
		java.util.List<VRInspectionStandard> vrInspectionStandards);

	/**
	* Creates a new vr inspection standard with the primary key. Does not add the vr inspection standard to the database.
	*
	* @param id the primary key for the new vr inspection standard
	* @return the new vr inspection standard
	*/
	public VRInspectionStandard create(long id);

	/**
	* Removes the vr inspection standard with the primary key from the database. Also notifies the appropriate model listeners.
	*
	* @param id the primary key of the vr inspection standard
	* @return the vr inspection standard that was removed
	* @throws NoSuchVRInspectionStandardException if a vr inspection standard with the primary key could not be found
	*/
	public VRInspectionStandard remove(long id)
		throws NoSuchVRInspectionStandardException;

	public VRInspectionStandard updateImpl(
		VRInspectionStandard vrInspectionStandard);

	/**
	* Returns the vr inspection standard with the primary key or throws a {@link NoSuchVRInspectionStandardException} if it could not be found.
	*
	* @param id the primary key of the vr inspection standard
	* @return the vr inspection standard
	* @throws NoSuchVRInspectionStandardException if a vr inspection standard with the primary key could not be found
	*/
	public VRInspectionStandard findByPrimaryKey(long id)
		throws NoSuchVRInspectionStandardException;

	/**
	* Returns the vr inspection standard with the primary key or returns <code>null</code> if it could not be found.
	*
	* @param id the primary key of the vr inspection standard
	* @return the vr inspection standard, or <code>null</code> if a vr inspection standard with the primary key could not be found
	*/
	public VRInspectionStandard fetchByPrimaryKey(long id);

	@Override
	public java.util.Map<java.io.Serializable, VRInspectionStandard> fetchByPrimaryKeys(
		java.util.Set<java.io.Serializable> primaryKeys);

	/**
	* Returns all the vr inspection standards.
	*
	* @return the vr inspection standards
	*/
	public java.util.List<VRInspectionStandard> findAll();

	/**
	* Returns a range of all the vr inspection standards.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link VRInspectionStandardModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of vr inspection standards
	* @param end the upper bound of the range of vr inspection standards (not inclusive)
	* @return the range of vr inspection standards
	*/
	public java.util.List<VRInspectionStandard> findAll(int start, int end);

	/**
	* Returns an ordered range of all the vr inspection standards.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link VRInspectionStandardModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of vr inspection standards
	* @param end the upper bound of the range of vr inspection standards (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @return the ordered range of vr inspection standards
	*/
	public java.util.List<VRInspectionStandard> findAll(int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<VRInspectionStandard> orderByComparator);

	/**
	* Returns an ordered range of all the vr inspection standards.
	*
	* <p>
	* Useful when paginating results. Returns a maximum of <code>end - start</code> instances. <code>start</code> and <code>end</code> are not primary keys, they are indexes in the result set. Thus, <code>0</code> refers to the first result in the set. Setting both <code>start</code> and <code>end</code> to {@link QueryUtil#ALL_POS} will return the full result set. If <code>orderByComparator</code> is specified, then the query will include the given ORDER BY logic. If <code>orderByComparator</code> is absent and pagination is required (<code>start</code> and <code>end</code> are not {@link QueryUtil#ALL_POS}), then the query will include the default ORDER BY logic from {@link VRInspectionStandardModelImpl}. If both <code>orderByComparator</code> and pagination are absent, for performance reasons, the query will not have an ORDER BY clause and the returned result set will be sorted on by the primary key in an ascending order.
	* </p>
	*
	* @param start the lower bound of the range of vr inspection standards
	* @param end the upper bound of the range of vr inspection standards (not inclusive)
	* @param orderByComparator the comparator to order the results by (optionally <code>null</code>)
	* @param retrieveFromCache whether to retrieve from the finder cache
	* @return the ordered range of vr inspection standards
	*/
	public java.util.List<VRInspectionStandard> findAll(int start, int end,
		com.liferay.portal.kernel.util.OrderByComparator<VRInspectionStandard> orderByComparator,
		boolean retrieveFromCache);

	/**
	* Removes all the vr inspection standards from the database.
	*/
	public void removeAll();

	/**
	* Returns the number of vr inspection standards.
	*
	* @return the number of vr inspection standards
	*/
	public int countAll();
}