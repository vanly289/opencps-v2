/**
 * Copyright (c) 2000-present Liferay, Inc. All rights reserved.
 *
 * This library is free software; you can redistribute it and/or modify it under
 * the terms of the GNU Lesser General Public License as published by the Free
 * Software Foundation; either version 2.1 of the License, or (at your option)
 * any later version.
 *
 * This library is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License for more
 * details.
 */

package com.fds.vr.business.model;

import aQute.bnd.annotation.ProviderType;

import java.io.Serializable;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * This class is used by SOAP remote services, specifically {@link com.fds.vr.business.service.http.VROutputSheetDetailsServiceSoap}.
 *
 * @author LamTV
 * @see com.fds.vr.business.service.http.VROutputSheetDetailsServiceSoap
 * @generated
 */
@ProviderType
public class VROutputSheetDetailsSoap implements Serializable {
	public static VROutputSheetDetailsSoap toSoapModel(
		VROutputSheetDetails model) {
		VROutputSheetDetailsSoap soapModel = new VROutputSheetDetailsSoap();

		soapModel.setId(model.getId());
		soapModel.setInputSheetId(model.getInputSheetId());
		soapModel.setOutputSheetId(model.getOutputSheetId());
		soapModel.setBookId(model.getBookId());
		soapModel.setIssueVehicleCertificateId(model.getIssueVehicleCertificateId());
		soapModel.setCertificateId(model.getCertificateId());
		soapModel.setCertificateNumber(model.getCertificateNumber());
		soapModel.setCertificateDate(model.getCertificateDate());
		soapModel.setVehicleClass(model.getVehicleClass());
		soapModel.setStampType(model.getStampType());
		soapModel.setStampShortNo(model.getStampShortNo());
		soapModel.setSerialStartNo(model.getSerialStartNo());
		soapModel.setSerialEndNo(model.getSerialEndNo());
		soapModel.setSubTotalInDocument(model.getSubTotalInDocument());
		soapModel.setSubTotalQuantities(model.getSubTotalQuantities());
		soapModel.setUnitPrice(model.getUnitPrice());
		soapModel.setTotalAmount(model.getTotalAmount());
		soapModel.setTotalInUse(model.getTotalInUse());
		soapModel.setTotalNotUsed(model.getTotalNotUsed());
		soapModel.setTotalLost(model.getTotalLost());
		soapModel.setTotalCancelled(model.getTotalCancelled());
		soapModel.setTotalReturned(model.getTotalReturned());
		soapModel.setRemark(model.getRemark());
		soapModel.setModifyDate(model.getModifyDate());
		soapModel.setSyncDate(model.getSyncDate());

		return soapModel;
	}

	public static VROutputSheetDetailsSoap[] toSoapModels(
		VROutputSheetDetails[] models) {
		VROutputSheetDetailsSoap[] soapModels = new VROutputSheetDetailsSoap[models.length];

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModel(models[i]);
		}

		return soapModels;
	}

	public static VROutputSheetDetailsSoap[][] toSoapModels(
		VROutputSheetDetails[][] models) {
		VROutputSheetDetailsSoap[][] soapModels = null;

		if (models.length > 0) {
			soapModels = new VROutputSheetDetailsSoap[models.length][models[0].length];
		}
		else {
			soapModels = new VROutputSheetDetailsSoap[0][0];
		}

		for (int i = 0; i < models.length; i++) {
			soapModels[i] = toSoapModels(models[i]);
		}

		return soapModels;
	}

	public static VROutputSheetDetailsSoap[] toSoapModels(
		List<VROutputSheetDetails> models) {
		List<VROutputSheetDetailsSoap> soapModels = new ArrayList<VROutputSheetDetailsSoap>(models.size());

		for (VROutputSheetDetails model : models) {
			soapModels.add(toSoapModel(model));
		}

		return soapModels.toArray(new VROutputSheetDetailsSoap[soapModels.size()]);
	}

	public VROutputSheetDetailsSoap() {
	}

	public long getPrimaryKey() {
		return _id;
	}

	public void setPrimaryKey(long pk) {
		setId(pk);
	}

	public long getId() {
		return _id;
	}

	public void setId(long id) {
		_id = id;
	}

	public long getInputSheetId() {
		return _inputSheetId;
	}

	public void setInputSheetId(long inputSheetId) {
		_inputSheetId = inputSheetId;
	}

	public long getOutputSheetId() {
		return _outputSheetId;
	}

	public void setOutputSheetId(long outputSheetId) {
		_outputSheetId = outputSheetId;
	}

	public long getBookId() {
		return _bookId;
	}

	public void setBookId(long bookId) {
		_bookId = bookId;
	}

	public long getIssueVehicleCertificateId() {
		return _issueVehicleCertificateId;
	}

	public void setIssueVehicleCertificateId(long issueVehicleCertificateId) {
		_issueVehicleCertificateId = issueVehicleCertificateId;
	}

	public long getCertificateId() {
		return _certificateId;
	}

	public void setCertificateId(long certificateId) {
		_certificateId = certificateId;
	}

	public String getCertificateNumber() {
		return _certificateNumber;
	}

	public void setCertificateNumber(String certificateNumber) {
		_certificateNumber = certificateNumber;
	}

	public Date getCertificateDate() {
		return _certificateDate;
	}

	public void setCertificateDate(Date certificateDate) {
		_certificateDate = certificateDate;
	}

	public long getVehicleClass() {
		return _vehicleClass;
	}

	public void setVehicleClass(long vehicleClass) {
		_vehicleClass = vehicleClass;
	}

	public String getStampType() {
		return _stampType;
	}

	public void setStampType(String stampType) {
		_stampType = stampType;
	}

	public String getStampShortNo() {
		return _stampShortNo;
	}

	public void setStampShortNo(String stampShortNo) {
		_stampShortNo = stampShortNo;
	}

	public String getSerialStartNo() {
		return _serialStartNo;
	}

	public void setSerialStartNo(String serialStartNo) {
		_serialStartNo = serialStartNo;
	}

	public String getSerialEndNo() {
		return _serialEndNo;
	}

	public void setSerialEndNo(String serialEndNo) {
		_serialEndNo = serialEndNo;
	}

	public long getSubTotalInDocument() {
		return _subTotalInDocument;
	}

	public void setSubTotalInDocument(long subTotalInDocument) {
		_subTotalInDocument = subTotalInDocument;
	}

	public long getSubTotalQuantities() {
		return _subTotalQuantities;
	}

	public void setSubTotalQuantities(long subTotalQuantities) {
		_subTotalQuantities = subTotalQuantities;
	}

	public long getUnitPrice() {
		return _unitPrice;
	}

	public void setUnitPrice(long unitPrice) {
		_unitPrice = unitPrice;
	}

	public long getTotalAmount() {
		return _totalAmount;
	}

	public void setTotalAmount(long totalAmount) {
		_totalAmount = totalAmount;
	}

	public long getTotalInUse() {
		return _totalInUse;
	}

	public void setTotalInUse(long totalInUse) {
		_totalInUse = totalInUse;
	}

	public long getTotalNotUsed() {
		return _totalNotUsed;
	}

	public void setTotalNotUsed(long totalNotUsed) {
		_totalNotUsed = totalNotUsed;
	}

	public long getTotalLost() {
		return _totalLost;
	}

	public void setTotalLost(long totalLost) {
		_totalLost = totalLost;
	}

	public long getTotalCancelled() {
		return _totalCancelled;
	}

	public void setTotalCancelled(long totalCancelled) {
		_totalCancelled = totalCancelled;
	}

	public long getTotalReturned() {
		return _totalReturned;
	}

	public void setTotalReturned(long totalReturned) {
		_totalReturned = totalReturned;
	}

	public String getRemark() {
		return _remark;
	}

	public void setRemark(String remark) {
		_remark = remark;
	}

	public Date getModifyDate() {
		return _modifyDate;
	}

	public void setModifyDate(Date modifyDate) {
		_modifyDate = modifyDate;
	}

	public Date getSyncDate() {
		return _syncDate;
	}

	public void setSyncDate(Date syncDate) {
		_syncDate = syncDate;
	}

	private long _id;
	private long _inputSheetId;
	private long _outputSheetId;
	private long _bookId;
	private long _issueVehicleCertificateId;
	private long _certificateId;
	private String _certificateNumber;
	private Date _certificateDate;
	private long _vehicleClass;
	private String _stampType;
	private String _stampShortNo;
	private String _serialStartNo;
	private String _serialEndNo;
	private long _subTotalInDocument;
	private long _subTotalQuantities;
	private long _unitPrice;
	private long _totalAmount;
	private long _totalInUse;
	private long _totalNotUsed;
	private long _totalLost;
	private long _totalCancelled;
	private long _totalReturned;
	private String _remark;
	private Date _modifyDate;
	private Date _syncDate;
}