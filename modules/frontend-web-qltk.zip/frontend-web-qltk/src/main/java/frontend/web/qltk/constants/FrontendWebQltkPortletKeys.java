package frontend.web.qltk.constants;

/**
 * @author khoavu
 */
public class FrontendWebQltkPortletKeys {

	public static final String FrontendWebQltk = "FrontendWebQltk";

}